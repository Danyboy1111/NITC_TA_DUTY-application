import mongoose from "mongoose";

const studentSchema=new mongoose.Schema({

name:{
    type:String,
    required:true,
},
id :{
type:Number,
required:true,
},
image:
{
    type:String,
    required:true,
},
lab:
{
type:Number,
required:true,
},
teach:{

type:Number,
required:true,
},
project:{
type:Number,
required :true,
},
},
{
    timestamps:true,
});
const Student = mongoose.model("Student",studentSchema);
export default Student;