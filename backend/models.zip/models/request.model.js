import mongoose from "mongoose";

const requestSchema=new mongoose.Schema({

name:{
    type:String,
    required:true,
},
id:{
    type:String,
    required:true,
},
type:{
    type:String,
    required:true,
},
msg:{
type:String,
required: true,
},
},
{
    timestamps:true,
});
const Request = mongoose.model("Request",requestSchema);
export default Request;