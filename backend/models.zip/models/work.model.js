import mongoose from "mongoose";

const workSchema=new mongoose.Schema({

id :{
type:Number,
required:true,
},
msg:
{
    type:String,
    required:true,
}
},
{
    timestamps:true,
});
const Work = mongoose.model("Work",workSchema);
export default Work;